package com.example.nazrulhaque.whackamole;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.os.Handler;

import java.util.Locale;
import java.util.Random;

public class Game1 extends AppCompatActivity {
    private String gameName ="game1";
    private static final long START_TIME_MILLI = 600000;
    private TextView timer;
    private Button start;
    private Button g1r1c1;
    private Button g1r1c2;
    private Button g1r1c3;
    private Button g1r2c1;
    private Button g1r2c2;
    private Button g1r2c3;
    private int randInt;
    private boolean mTimeRunning=true;
    private long mTimeLeft;


    private TextView score;
    private int val =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game1);
        timer = (TextView) findViewById(R.id.Time);
        g1r1c1 = (Button) findViewById(R.id.G1R1C1);
        g1r1c2 = (Button) findViewById(R.id.G1R1C2);
        g1r1c3 = (Button) findViewById(R.id.G1R1C3);
        g1r2c1 = (Button) findViewById(R.id.G1R2C1);
        g1r2c2 = (Button) findViewById(R.id.G1R2C2);
        g1r2c3 = (Button) findViewById(R.id.G1R2C3);
        start = (Button) findViewById(R.id.start);
        score = (TextView) findViewById(R.id.score);
        final Button[] buttons = {g1r1c1, g1r1c2, g1r1c3, g1r2c1, g1r2c2, g1r2c3};

        final Random rand = new Random();
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val =0;
                start.setVisibility(View.INVISIBLE);
                new CountDownTimer(60000, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        mTimeLeft = millisUntilFinished;
                        updateCountDownText();
                        randInt = rand.nextInt(buttons.length);
                        Handler handler = new Handler();
                        buttons[randInt].setVisibility(View.VISIBLE);
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                buttons[randInt].setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        val += 1;
                                        score.setText("Score: " + Integer.toString(val));

                                    }
                                });
                                buttons[randInt].setVisibility(View.INVISIBLE);

                            }

                        }, 600);

                   }
                    @Override
                    public void onFinish() {
                        Intent intent = new Intent(getApplicationContext(), FinishActivity.class);
                        FinishActivity.SCORE_VALUE= Integer.toString(val);
                        FinishActivity.start_new=gameName;
                        startActivity(intent);

                    }

                }.start();

                }



        });




    }

    public void updateCountDownText()
    {
        int seconds = (int) (mTimeLeft/1000);
        String timeLeftFormatted = String.format(Locale.getDefault(),"0:%02d", seconds);
        timer.setText(timeLeftFormatted);

    }
}

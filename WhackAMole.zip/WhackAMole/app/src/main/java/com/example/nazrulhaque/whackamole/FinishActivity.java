package com.example.nazrulhaque.whackamole;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;

public class FinishActivity extends AppCompatActivity {
    public static String SCORE_VALUE ;
    public static String start_new;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finish);
        Intent intent= getIntent();
        TextView scoreDis =  findViewById(R.id.scoreDisplay);
        scoreDis.setText(SCORE_VALUE);
    }
    public void startAgain(View view){
        if(start_new == "game1"){
            Intent intent = new Intent(this, Game1.class);
            startActivity(intent);
        }
        else if(start_new == "game2")
        {
            Intent intent = new Intent(this, Game2.class);
            startActivity(intent);
        }
        else{
            Intent intent = new Intent(this, Game3.class);
            startActivity(intent);
        }

    }
    public void exit(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}

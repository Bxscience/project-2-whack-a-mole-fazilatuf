package com.example.nazrulhaque.whackamole;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.os.Handler;

import java.util.Locale;
import java.util.Random;

public class Game3 extends AppCompatActivity {
    private String gameName ="game3";
    private Button g3r1c1;
    private Button g3r1c2;
    private Button g3r1c3;
    private Button g3r1c4;
    private Button g3r1c5;

    private Button g3r2c1;
    private Button g3r2c2;
    private Button g3r2c3;
    private Button g3r2c4;
    private Button g3r2c5;

    private Button g3r3c1;
    private Button g3r3c2;
    private Button g3r3c3;
    private Button g3r3c4;
    private Button g3r3c5;

    private Button g3r4c1;
    private Button g3r4c2;
    private Button g3r4c3;
    private Button g3r4c4;
    private Button g3r4c5;

    private TextView timer3;
    private Button start3;
    private int randInt;
    private long mTimeLeft;
    private TextView score3;
    private int val = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game3);
        timer3 = (TextView) findViewById(R.id.time3);
        g3r1c1 = (Button) findViewById(R.id.G3R1C1);
        g3r1c2 = (Button) findViewById(R.id.G3R1C2);
        g3r1c3 = (Button) findViewById(R.id.G3R1C3);
        g3r1c4 = (Button) findViewById(R.id.G3R1C4);
        g3r1c5 = (Button) findViewById(R.id.G3R1C5);

        g3r2c1 = (Button) findViewById(R.id.G3R2C1);
        g3r2c2 = (Button) findViewById(R.id.G3R2C2);
        g3r2c3 = (Button) findViewById(R.id.G3R2C3);
        g3r2c4 = (Button) findViewById(R.id.G3R2C4);
        g3r2c5 = (Button) findViewById(R.id.G3R2C5);

        g3r3c1 = (Button) findViewById(R.id.G3R3C1);
        g3r3c2 = (Button) findViewById(R.id.G3R3C2);
        g3r3c3 = (Button) findViewById(R.id.G3R3C3);
        g3r3c4 = (Button) findViewById(R.id.G3R3C4);
        g3r3c5 = (Button) findViewById(R.id.G3R3C5);

        g3r4c1 = (Button) findViewById(R.id.G3R4C1);
        g3r4c2 = (Button) findViewById(R.id.G3R4C2);
        g3r4c3 = (Button) findViewById(R.id.G3R4C3);
        g3r4c4 = (Button) findViewById(R.id.G3R4C4);
        g3r4c5 = (Button) findViewById(R.id.G3R4C5);

        start3 = (Button) findViewById(R.id.start3);
        score3 = (TextView) findViewById(R.id.score3);
        final Button[] buttons = {g3r1c1, g3r1c2, g3r1c3,g3r1c4,g3r1c5, g3r2c1, g3r2c2, g3r2c3, g3r2c4,g3r2c5, g3r3c1, g3r3c2,g3r3c3, g3r3c4,g3r3c5,g3r4c1, g3r4c2,g3r4c3, g3r4c4,g3r4c5};

        final Random rand = new Random();


        start3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start3.setVisibility(View.INVISIBLE);
                new CountDownTimer(60000, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        mTimeLeft = millisUntilFinished;
                        updateCountDownText();
                        randInt = rand.nextInt(buttons.length);
                        Handler handler = new Handler();
                        buttons[randInt].setVisibility(View.VISIBLE);
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                buttons[randInt].setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        val += 1;
                                        score3.setText("Score: " + Integer.toString(val));

                                    }
                                });
                                buttons[randInt].setVisibility(View.INVISIBLE);
                            }
                        }, 600);

                    }
                    @Override
                    public void onFinish() {
                        Intent intent = new Intent(getApplicationContext(), FinishActivity.class);
                        FinishActivity.SCORE_VALUE= Integer.toString(val);
                        FinishActivity.start_new=gameName;
                        startActivity(intent);
                    }
                }.start();
            }
        });



    }

    public void updateCountDownText()
    {
        int seconds = (int) (mTimeLeft/1000);
        String timeLeftFormatted = String.format(Locale.getDefault(),"0:%02d", seconds);
        timer3.setText(timeLeftFormatted);

    }
}

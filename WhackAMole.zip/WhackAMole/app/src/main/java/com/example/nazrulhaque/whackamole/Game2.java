package com.example.nazrulhaque.whackamole;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.os.Handler;

import java.util.Locale;
import java.util.Random;

public class Game2 extends AppCompatActivity {
    private String gameName ="game2";
    private TextView timer;
    private Button start2;
    private Button g2r1c1;
    private Button g2r1c2;
    private Button g2r1c3;
    private Button g2r1c4;
    private Button g2r2c1;
    private Button g2r2c2;
    private Button g2r2c3;
    private Button g2r2c4;
    private Button g2r3c1;
    private Button g2r3c2;
    private Button g2r3c3;
    private Button g2r3c4;

    private int randInt;
    private long mTimeLeft;

    private TextView score2;
    private int val = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game2);

       timer = (TextView) findViewById(R.id.time2);
        g2r1c1 = (Button) findViewById(R.id.G2R1C1);
        g2r1c2 = (Button) findViewById(R.id.G2R1C2);
        g2r1c3 = (Button) findViewById(R.id.G2R1C3);
        g2r1c4 = (Button) findViewById(R.id.G2R1C4);
        g2r2c1 = (Button) findViewById(R.id.G2R2C1);
        g2r2c2 = (Button) findViewById(R.id.G2R2C2);
        g2r2c3 = (Button) findViewById(R.id.G2R2C3);
        g2r2c4 = (Button) findViewById(R.id.G2R2C4);
        g2r3c1 = (Button) findViewById(R.id.G2R3C1);
        g2r3c2 = (Button) findViewById(R.id.G2R3C2);;
        g2r3c3 = (Button) findViewById(R.id.G2R3C3);;
        g2r3c4 = (Button) findViewById(R.id.G2R3C4);;
        start2 = (Button) findViewById(R.id.start2);
        score2 = (TextView) findViewById(R.id.score2);

        final Button[] buttons = {g2r1c1, g2r1c2, g2r1c3,g2r1c4, g2r2c1, g2r2c2, g2r2c3, g2r2c4, g2r3c1, g2r3c2,g2r3c3, g2r3c4};
        final Random rand = new Random();


        start2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start2.setVisibility(View.INVISIBLE);
                new CountDownTimer(60000, 1000) {
                    @Override
                    public void onTick(final long millisUntilFinished) {
                        mTimeLeft = millisUntilFinished;
                        updateCountDownText();
                        randInt = rand.nextInt(buttons.length);
                        Handler handler = new Handler();
                        buttons[randInt].setVisibility(View.VISIBLE);
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                buttons[randInt].setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                            val += 1;
                                            score2.setText("Score: " + Integer.toString(val));
                                    }
                                });
                                buttons[randInt].setVisibility(View.INVISIBLE);

                            }
                        }, 600);

                    }
                    @Override
                    public void onFinish() {
                        Intent intent = new Intent(getApplicationContext(), FinishActivity.class);
                        FinishActivity.SCORE_VALUE= Integer.toString(val);
                        FinishActivity.start_new=gameName;
                        startActivity(intent);

                    }
                }.start();
            }
        });



    }

    public void updateCountDownText()
    {
        int seconds = (int) (mTimeLeft/1000);
        String timeLeftFormatted = String.format(Locale.getDefault(),"0:%02d", seconds);
        timer.setText(timeLeftFormatted);

    }
}
